import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import api from '../utils/api';
import Sidebar from '../components/Sidebar';
import TimelineView from '../components/TimelineView';
import EventModal from '../components/EventModal';
import StoryMode from '../components/StoryMode';
import Toast from '../components/Toast';
import './TimelinePage.css';

export default function TimelinePage() {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState('timeline'); // 'timeline' | 'grid'
  const [showModal, setShowModal] = useState(false);
  const [editingEvent, setEditingEvent] = useState(null);
  const [storyMode, setStoryMode] = useState(false);
  const [toast, setToast] = useState(null);
  const [filters, setFilters] = useState({ mood: '', tag: '', sort: 'date', order: 'desc' });
  const [editMode, setEditMode] = useState(false);

  const fetchEvents = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (filters.mood) params.set('mood', filters.mood);
      if (filters.tag) params.set('tag', filters.tag);
      params.set('sort', filters.sort);
      params.set('order', filters.order);
      const res = await api.get(`/events?${params}`);
      setEvents(res.data);
    } catch (err) {
      showToast('Failed to load events', 'error');
    } finally {
      setLoading(false);
    }
  }, [filters]);

  useEffect(() => { fetchEvents(); }, [fetchEvents]);

  const showToast = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  };

  const handleCreateEvent = async (data) => {
    try {
      const res = await api.post('/events', data);
      setEvents(prev => [res.data, ...prev]);
      showToast('Memory added ✦');
      setShowModal(false);
    } catch (err) {
      showToast(err.response?.data?.message || 'Failed to create event', 'error');
    }
  };

  const handleUpdateEvent = async (id, data) => {
    try {
      const res = await api.put(`/events/${id}`, data);
      setEvents(prev => prev.map(e => e._id === id ? res.data : e));
      showToast('Memory updated');
      setEditingEvent(null);
    } catch (err) {
      showToast('Failed to update event', 'error');
    }
  };

  const handleDeleteEvent = async (id) => {
    if (!window.confirm('Delete this memory forever?')) return;
    try {
      await api.delete(`/events/${id}`);
      setEvents(prev => prev.filter(e => e._id !== id));
      showToast('Memory removed');
    } catch (err) {
      showToast('Failed to delete event', 'error');
    }
  };

  const handleReorder = async (newOrder) => {
    setEvents(newOrder);
    try {
      await api.put('/events/reorder/bulk', { orderedIds: newOrder.map(e => e._id) });
    } catch (err) {
      showToast('Failed to save order', 'error');
    }
  };

  const openEdit = (event) => {
    setEditingEvent(event);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditingEvent(null);
  };

  const allTags = [...new Set(events.flatMap(e => e.tags || []))];

  return (
    <div className="timeline-page">
      <Sidebar
        user={user}
        view={view}
        setView={setView}
        filters={filters}
        setFilters={setFilters}
        allTags={allTags}
        editMode={editMode}
        setEditMode={setEditMode}
        onLogout={logout}
        theme={theme}
        toggleTheme={toggleTheme}
        onStoryMode={() => setStoryMode(true)}
        eventCount={events.length}
      />

      <main className="timeline-main">
        <div className="timeline-header">
          <div>
            <h1 className="timeline-heading">
              <span className="font-display">{user?.name?.split(' ')[0]}'s</span> Timeline
            </h1>
            <p className="timeline-subheading">
              {events.length === 0 ? 'Your story begins here.' : `${events.length} memor${events.length === 1 ? 'y' : 'ies'} captured`}
            </p>
          </div>
          <button className="btn btn-primary" onClick={() => { setEditingEvent(null); setShowModal(true); }}>
            <span style={{ fontSize: '18px', lineHeight: 1 }}>+</span> Add Memory
          </button>
        </div>

        {loading ? (
          <div className="timeline-loading">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="skeleton-card skeleton" style={{ height: '180px', borderRadius: '16px', marginBottom: '24px', animationDelay: `${i * 0.15}s` }} />
            ))}
          </div>
        ) : events.length === 0 ? (
          <div className="timeline-empty">
            <div className="empty-icon animate-float">✦</div>
            <h3>No memories yet</h3>
            <p>Start by adding your first memory to build your personal timeline.</p>
            <button className="btn btn-primary btn-lg" onClick={() => setShowModal(true)}>
              Add Your First Memory
            </button>
          </div>
        ) : (
          <TimelineView
            events={events}
            view={view}
            editMode={editMode}
            onEdit={openEdit}
            onDelete={handleDeleteEvent}
            onReorder={handleReorder}
          />
        )}
      </main>

      {showModal && (
        <EventModal
          event={editingEvent}
          onSubmit={editingEvent
            ? (data) => handleUpdateEvent(editingEvent._id, data)
            : handleCreateEvent}
          onClose={closeModal}
        />
      )}

      {storyMode && (
        <StoryMode events={events} onClose={() => setStoryMode(false)} />
      )}

      {toast && <Toast message={toast.message} type={toast.type} />}
    </div>
  );
}
