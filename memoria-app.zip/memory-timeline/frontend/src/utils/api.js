import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json' },
});

const token = localStorage.getItem('memoria_token');
if (token) api.defaults.headers.common['Authorization'] = `Bearer ${token}`;

api.interceptors.response.use(
  res => res,
  err => {
    if (err.response?.status === 401) {
      localStorage.removeItem('memoria_token');
      delete api.defaults.headers.common['Authorization'];
      window.location.href = '/auth';
    }
    return Promise.reject(err);
  }
);

export default api;
