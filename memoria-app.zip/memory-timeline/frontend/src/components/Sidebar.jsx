import './Sidebar.css';

const MOODS = [
  { value: 'joyful', emoji: '😄', label: 'Joyful' },
  { value: 'nostalgic', emoji: '🌙', label: 'Nostalgic' },
  { value: 'proud', emoji: '🏆', label: 'Proud' },
  { value: 'sad', emoji: '💧', label: 'Sad' },
  { value: 'excited', emoji: '⚡', label: 'Excited' },
  { value: 'peaceful', emoji: '🕊', label: 'Peaceful' },
  { value: 'grateful', emoji: '🌸', label: 'Grateful' },
  { value: 'adventurous', emoji: '🗺', label: 'Adventurous' },
];

export default function Sidebar({
  user, view, setView, filters, setFilters, allTags,
  editMode, setEditMode, onLogout, theme, toggleTheme,
  onStoryMode, eventCount
}) {
  const clearFilters = () => setFilters({ mood: '', tag: '', sort: 'date', order: 'desc' });
  const hasFilters = filters.mood || filters.tag;

  return (
    <aside className="sidebar">
      <div className="sidebar-brand">
        <span className="logo-star">✦</span>
        <span className="sidebar-logo-text">Memoria</span>
      </div>

      {/* User */}
      <div className="sidebar-user">
        <div className="sidebar-avatar">
          {user?.avatar
            ? <img src={user.avatar} alt={user.name} />
            : <span>{user?.name?.[0]?.toUpperCase()}</span>}
        </div>
        <div className="sidebar-user-info">
          <div className="sidebar-user-name">{user?.name}</div>
          <div className="sidebar-user-count">{eventCount} memories</div>
        </div>
      </div>

      <nav className="sidebar-nav">
        {/* Views */}
        <div className="sidebar-section-label">View</div>
        <button className={`sidebar-btn ${view === 'timeline' ? 'active' : ''}`} onClick={() => setView('timeline')}>
          <span className="sidebar-btn-icon">◈</span> Timeline
        </button>
        <button className={`sidebar-btn ${view === 'grid' ? 'active' : ''}`} onClick={() => setView('grid')}>
          <span className="sidebar-btn-icon">⬡</span> Grid
        </button>

        {/* Actions */}
        <div className="sidebar-section-label">Actions</div>
        <button className={`sidebar-btn ${editMode ? 'active accent' : ''}`} onClick={() => setEditMode(e => !e)}>
          <span className="sidebar-btn-icon">⟐</span> {editMode ? 'Exit Edit Mode' : 'Edit Mode'}
        </button>
        <button className="sidebar-btn" onClick={onStoryMode}>
          <span className="sidebar-btn-icon">▷</span> Story Mode
        </button>

        {/* Sort */}
        <div className="sidebar-section-label">Sort</div>
        <div className="sidebar-sort">
          <select
            className="input"
            value={filters.sort}
            onChange={e => setFilters(f => ({ ...f, sort: e.target.value }))}
          >
            <option value="date">By Date</option>
            <option value="sortIndex">Custom Order</option>
            <option value="createdAt">Recently Added</option>
          </select>
          <button
            className="btn btn-ghost btn-sm"
            onClick={() => setFilters(f => ({ ...f, order: f.order === 'asc' ? 'desc' : 'asc' }))}
            title="Toggle order"
          >
            {filters.order === 'desc' ? '↓' : '↑'}
          </button>
        </div>

        {/* Mood filter */}
        <div className="sidebar-section-label">
          Filter by Mood
          {filters.mood && <button className="filter-clear-btn" onClick={() => setFilters(f => ({ ...f, mood: '' }))}>✕</button>}
        </div>
        <div className="mood-filter-grid">
          {MOODS.map(m => (
            <button
              key={m.value}
              className={`mood-filter-btn ${filters.mood === m.value ? 'active' : ''}`}
              onClick={() => setFilters(f => ({ ...f, mood: f.mood === m.value ? '' : m.value }))}
              title={m.label}
            >
              {m.emoji}
            </button>
          ))}
        </div>

        {/* Tag filter */}
        {allTags.length > 0 && (
          <>
            <div className="sidebar-section-label">
              Filter by Tag
              {filters.tag && <button className="filter-clear-btn" onClick={() => setFilters(f => ({ ...f, tag: '' }))}>✕</button>}
            </div>
            <div className="tag-filter-list">
              {allTags.map(tag => (
                <button
                  key={tag}
                  className={`tag ${filters.tag === tag ? 'tag-active' : ''}`}
                  onClick={() => setFilters(f => ({ ...f, tag: f.tag === tag ? '' : tag }))}
                >
                  #{tag}
                </button>
              ))}
            </div>
          </>
        )}

        {hasFilters && (
          <button className="btn btn-ghost btn-sm sidebar-clear-btn" onClick={clearFilters}>
            Clear All Filters
          </button>
        )}
      </nav>

      <div className="sidebar-footer">
        <button className="sidebar-btn" onClick={toggleTheme}>
          <span className="sidebar-btn-icon">{theme === 'dark' ? '☀' : '☾'}</span>
          {theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
        </button>
        <button className="sidebar-btn sidebar-logout" onClick={onLogout}>
          <span className="sidebar-btn-icon">⎋</span> Sign Out
        </button>
      </div>
    </aside>
  );
}
