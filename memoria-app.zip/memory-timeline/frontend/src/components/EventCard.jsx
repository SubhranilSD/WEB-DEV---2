import { useState } from 'react';
import './EventCard.css';

const MOOD_EMOJIS = {
  joyful: '😄', nostalgic: '🌙', proud: '🏆', sad: '💧',
  excited: '⚡', peaceful: '🕊', grateful: '🌸', adventurous: '🗺'
};

const MOOD_COLORS = {
  joyful: '#f59e0b', nostalgic: '#8b5cf6', proud: '#10b981', sad: '#6b7280',
  excited: '#ef4444', peaceful: '#06b6d4', grateful: '#ec4899', adventurous: '#f97316'
};

function formatDate(dateStr) {
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
}

export default function EventCard({ event, view, editMode, onEdit, onDelete }) {
  const [imgError, setImgError] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const moodColor = MOOD_COLORS[event.mood] || '#c4813a';
  const hasMedia = event.media && event.media.length > 0;

  return (
    <div
      className={`event-card glass-card ${view}`}
      style={{ '--event-color': event.color || moodColor }}
      onClick={() => !editMode && setExpanded(e => !e)}
    >
      {/* Color accent bar */}
      <div className="event-card-accent" style={{ background: event.color || moodColor }} />

      {/* Media */}
      {hasMedia && !imgError && (
        <div className="event-card-media">
          <img
            src={event.media[0].url}
            alt={event.title}
            onError={() => setImgError(true)}
            className="event-card-img"
          />
          {event.media.length > 1 && (
            <div className="event-card-media-count">+{event.media.length - 1}</div>
          )}
        </div>
      )}

      <div className="event-card-body">
        {/* Header */}
        <div className="event-card-header">
          <div>
            <div className="event-card-date">{formatDate(event.date)}</div>
            <h3 className="event-card-title">{event.title}</h3>
          </div>
          <div className={`mood-badge mood-${event.mood}`}>
            {MOOD_EMOJIS[event.mood]} {event.mood}
          </div>
        </div>

        {/* Location */}
        {event.location && (
          <div className="event-card-location">
            📍 {event.location}
          </div>
        )}

        {/* Description */}
        {event.description && (
          <p className={`event-card-desc ${expanded ? 'expanded' : ''}`}>
            {event.description}
          </p>
        )}

        {/* Tags */}
        {event.tags?.length > 0 && (
          <div className="event-card-tags">
            {event.tags.map(tag => (
              <span key={tag} className="tag">#{tag}</span>
            ))}
          </div>
        )}

        {/* Actions */}
        {editMode && (
          <div className="event-card-actions">
            <button
              className="btn btn-ghost btn-sm"
              onClick={(e) => { e.stopPropagation(); onEdit(event); }}
            >
              Edit
            </button>
            <button
              className="btn btn-danger btn-sm"
              onClick={(e) => { e.stopPropagation(); onDelete(event._id); }}
            >
              Delete
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
