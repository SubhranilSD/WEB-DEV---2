import { useState, useRef } from 'react';
import api from '../utils/api';
import './EventModal.css';

const MOODS = [
  { value: 'joyful', emoji: '😄', label: 'Joyful' },
  { value: 'nostalgic', emoji: '🌙', label: 'Nostalgic' },
  { value: 'proud', emoji: '🏆', label: 'Proud' },
  { value: 'sad', emoji: '💧', label: 'Sad' },
  { value: 'excited', emoji: '⚡', label: 'Excited' },
  { value: 'peaceful', emoji: '🕊', label: 'Peaceful' },
  { value: 'grateful', emoji: '🌸', label: 'Grateful' },
  { value: 'adventurous', emoji: '🗺', label: 'Adventurous' },
];

const COLORS = ['#c4813a', '#c46080', '#5b72c4', '#6b8f71', '#e8a85a', '#8b5cf6', '#06b6d4', '#ef4444'];

const today = () => new Date().toISOString().split('T')[0];

export default function EventModal({ event, onSubmit, onClose }) {
  const [form, setForm] = useState({
    title: event?.title || '',
    description: event?.description || '',
    date: event?.date ? new Date(event.date).toISOString().split('T')[0] : today(),
    location: event?.location || '',
    mood: event?.mood || 'joyful',
    tags: event?.tags?.join(', ') || '',
    color: event?.color || '#c4813a',
    isPrivate: event?.isPrivate || false,
    media: event?.media || [],
  });
  const [tagInput, setTagInput] = useState(event?.tags?.join(', ') || '');
  const [uploading, setUploading] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const fileRef = useRef(null);
  const [dragOver, setDragOver] = useState(false);

  const handleFile = async (files) => {
    if (!files?.length) return;
    setUploading(true);
    const newMedia = [];
    for (const file of files) {
      if (!file.type.startsWith('image/')) continue;
      const reader = new FileReader();
      await new Promise(resolve => {
        reader.onload = async (e) => {
          try {
            const res = await api.post('/upload', { base64: e.target.result, filename: file.name });
            newMedia.push(res.data);
          } catch {}
          resolve();
        };
        reader.readAsDataURL(file);
      });
    }
    setForm(f => ({ ...f, media: [...f.media, ...newMedia] }));
    setUploading(false);
  };

  const removeMedia = (idx) => {
    setForm(f => ({ ...f, media: f.media.filter((_, i) => i !== idx) }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.title.trim() || !form.date) { setError('Title and date are required'); return; }
    setLoading(true);
    setError('');
    try {
      const tags = tagInput.split(',').map(t => t.trim()).filter(Boolean);
      await onSubmit({ ...form, tags });
    } catch (err) {
      setError(err.response?.data?.message || 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal-content event-modal">
        <div className="modal-header">
          <h2 className="modal-title font-display">
            {event ? 'Edit Memory' : 'Add a Memory'}
          </h2>
          <button className="modal-close btn btn-ghost btn-icon" onClick={onClose}>✕</button>
        </div>

        <form onSubmit={handleSubmit}>
          {/* Title */}
          <div className="form-group">
            <label className="input-label">Title *</label>
            <input
              className="input"
              type="text"
              placeholder="What happened?"
              value={form.title}
              onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
              required
              maxLength={100}
            />
          </div>

          {/* Date & Location */}
          <div className="modal-row">
            <div className="form-group">
              <label className="input-label">Date *</label>
              <input
                className="input"
                type="date"
                value={form.date}
                onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
                required
              />
            </div>
            <div className="form-group">
              <label className="input-label">Location</label>
              <input
                className="input"
                type="text"
                placeholder="Where were you?"
                value={form.location}
                onChange={e => setForm(f => ({ ...f, location: e.target.value }))}
              />
            </div>
          </div>

          {/* Description */}
          <div className="form-group">
            <label className="input-label">Description</label>
            <textarea
              className="input"
              placeholder="Tell the story of this moment…"
              value={form.description}
              onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
              rows={4}
            />
          </div>

          {/* Mood */}
          <div className="form-group">
            <label className="input-label">Mood</label>
            <div className="mood-grid">
              {MOODS.map(m => (
                <button
                  key={m.value}
                  type="button"
                  className={`mood-btn ${form.mood === m.value ? 'active' : ''}`}
                  onClick={() => setForm(f => ({ ...f, mood: m.value }))}
                  title={m.label}
                >
                  <span className="mood-emoji">{m.emoji}</span>
                  <span className="mood-label">{m.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Color */}
          <div className="form-group">
            <label className="input-label">Card Color</label>
            <div className="color-picker">
              {COLORS.map(c => (
                <button
                  key={c}
                  type="button"
                  className={`color-dot ${form.color === c ? 'active' : ''}`}
                  style={{ background: c }}
                  onClick={() => setForm(f => ({ ...f, color: c }))}
                />
              ))}
            </div>
          </div>

          {/* Tags */}
          <div className="form-group">
            <label className="input-label">Tags (comma separated)</label>
            <input
              className="input"
              type="text"
              placeholder="travel, milestone, family…"
              value={tagInput}
              onChange={e => setTagInput(e.target.value)}
            />
          </div>

          {/* Media upload */}
          <div className="form-group">
            <label className="input-label">Photos</label>
            <div
              className={`media-dropzone ${dragOver ? 'drag-over' : ''}`}
              onClick={() => fileRef.current?.click()}
              onDragOver={e => { e.preventDefault(); setDragOver(true); }}
              onDragLeave={() => setDragOver(false)}
              onDrop={e => { e.preventDefault(); setDragOver(false); handleFile(e.dataTransfer.files); }}
            >
              {uploading ? (
                <span className="media-uploading">Uploading…</span>
              ) : (
                <>
                  <span className="media-icon">📷</span>
                  <span>Drop photos here or click to browse</span>
                </>
              )}
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                multiple
                style={{ display: 'none' }}
                onChange={e => handleFile(e.target.files)}
              />
            </div>

            {form.media.length > 0 && (
              <div className="media-preview">
                {form.media.map((m, i) => (
                  <div key={i} className="media-preview-item">
                    <img src={m.url} alt="" />
                    <button type="button" className="media-remove" onClick={() => removeMedia(i)}>✕</button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Private toggle */}
          <div className="form-group modal-private">
            <label className="toggle-label">
              <input
                type="checkbox"
                checked={form.isPrivate}
                onChange={e => setForm(f => ({ ...f, isPrivate: e.target.checked }))}
              />
              <span>Make this memory private</span>
            </label>
          </div>

          {error && <div className="auth-error" style={{ marginBottom: '16px' }}><span>⚠</span> {error}</div>}

          <div className="modal-footer">
            <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? '…' : event ? 'Save Changes' : 'Add Memory'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
